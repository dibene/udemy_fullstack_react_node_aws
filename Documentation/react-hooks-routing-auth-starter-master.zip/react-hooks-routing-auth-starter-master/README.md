A starter react hooks project with routing and authentication

