import React from 'react'

const Callback = props => (
    <div>
      Callback
    </div>
);

export default Callback;
