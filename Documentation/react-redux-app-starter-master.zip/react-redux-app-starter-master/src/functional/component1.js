import React from 'react'

const Component1 = props => (
    <div>
    Component 1
    {console.log(props)}
    </div>
);

export default Component1;
