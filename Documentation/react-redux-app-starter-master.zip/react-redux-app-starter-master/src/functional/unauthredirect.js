import React from 'react'

const UnauthRedirect = props => (
    <div>
      UnauthRedirect
    </div>
);

export default UnauthRedirect;
