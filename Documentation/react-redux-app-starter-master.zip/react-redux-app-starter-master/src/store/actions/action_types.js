

export const SUCCESS = "SUCCESS"

export const FAILURE = "FAILURE"

export const USER_INPUT = "USER_INPUT"

export const LOGIN_SUCCESS = "LOGIN_SUCCESS"

export const LOGIN_FAILURE = "LOGIN_FAILURE"

export const ADD_PROFILE = "ADD_PROFILE"

export const REMOVE_PROFILE = "REMOVE_PROFILE"
