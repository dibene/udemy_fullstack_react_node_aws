import React, { Component } from 'react';
import Routes from './routes';



class App extends Component {

  render() {
    return(
      <div>
      React
      <Routes />
      </div>
    )}
}


export default App;
